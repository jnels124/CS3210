# Introduction to hw1

TODO: write [great documentation](http://jacobian.org/writing/what-to-write/)
