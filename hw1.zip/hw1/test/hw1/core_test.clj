(ns hw1.core-test
  (:require [clojure.test :refer :all]
            [hw1.core :refer :all]))

(deftest a-test
  (testing "FIXME, I fail."
    (is (= 0 1))))
